import SwiftUI

// Creates a structure (Transaction), that creates variables with assigned types. These variables are used to create a standardized list that can be plugged into a dictionary of all the people who contributed and the amount that they paid.

struct Transaction {
    let contributor: String
    let totalCost: Double
    let group: [String]
}

// Function that uses the structure, Transaction, to calculate the actual amount that everyone should contribute.
// The logic in here makes it to where they all have to split parts of the check equally, and the person who paid (contributor)gets reimbursed by how much everyone else owes.

func computeContributions(transactions: [Transaction]) -> [String: Double] {
    var contributionBalance = [String: Double]()

    for transaction in transactions {
        let fairShare = transaction.totalCost / Double(transaction.group.count)

        for member in transaction.group {
            if member == transaction.contributor {
                continue
            }
            contributionBalance[member, default: 0] -= fairShare
        }

        contributionBalance[transaction.contributor, default: 0] += transaction.totalCost - fairShare
    }

    return contributionBalance
}

//Instances that I created to prove that my code works (david could have paid for all of the entres and Emma could have paid for appetizers for her and Frank)

let transactions = [
    Transaction(contributor: "David", totalCost: 45, group: ["David", "Emma", "Frank"]),
    Transaction(contributor: "Emma", totalCost: 25, group: ["Emma", "Frank"])
]

let finalBalances = computeContributions(transactions: transactions)

// Print Statements

for (individual, balance) in finalBalances {
    if balance > 0 {
        print("\(individual) is owed $\(balance)")
    } else if balance < 0 {
        print("\(individual) owes $\(-balance)")
    } else {
        print("\(individual) has settled their share.") // Updated output statement
    }
}
