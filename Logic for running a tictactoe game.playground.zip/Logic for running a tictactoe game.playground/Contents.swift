
//This file is some of the basic logic on how a game would play. it is different than what we did in class because its logic makes it to where you do not need to change the order of the moves based on the time you played it. in the one we did in class, all we did was append to a list, switch arould the order to fit winning statements, then all a winner. this one checks if you won based on a simulated board.

import Foundation

class TicTacToe {
    private var board: [[String]]
    private var currentPlayer: String
    
    init() {
        self.board = Array(repeating: Array(repeating: " ", count: 3), count: 3)
        self.currentPlayer = "X"
    }
    
    func printBoard() {
        for row in board {
            print(row.map { $0.isEmpty ? "_" : $0 }.joined(separator: " | "))
        }
        print("\n")
    }

    func playMove(row: Int, col: Int) -> Bool {
        if row < 0 || row >= 3 || col < 0 || col >= 3 || board[row][col] != " " {
            print("Invalid move. Try again.")
            return false
        }
        
        board[row][col] = currentPlayer
        
        if checkWinner() {
            printBoard()
            print("Player \(currentPlayer) wins.")
            return true
        }
        
        if checkDraw() {
            printBoard()
            print("The game is a draw.")
            return true
        }
        
        switchPlayer()
        return false
    }

    private func switchPlayer() {
        currentPlayer = (currentPlayer == "X") ? "O" : "X"
    }

    private func checkWinner() -> Bool {
        let winningPatterns = [
            [(0, 0), (0, 1), (0, 2)], //Row 1
            [(1, 0), (1, 1), (1, 2)], //Row 2
            [(2, 0), (2, 1), (2, 2)], //Row 3
            [(0, 0), (1, 0), (2, 0)], //Column 1
            [(0, 1), (1, 1), (2, 1)], //Column 2
            [(0, 2), (1, 2), (2, 2)], //Column 3
            [(0, 0), (1, 1), (2, 2)], //Diagonal 1
            [(0, 2), (1, 1), (2, 0)]  //Diagonal 2
        ]
        
        for pattern in winningPatterns {
            let (r1, c1) = pattern[0]
            let (r2, c2) = pattern[1]
            let (r3, c3) = pattern[2]

            if board[r1][c1] == currentPlayer &&
               board[r2][c2] == currentPlayer &&
               board[r3][c3] == currentPlayer {
                return true
            }
        }
        
        return false
    }

    private func checkDraw() -> Bool {
        return !board.joined().contains(" ")
    }

    func playGame() {
        var gameOver = false
        while !gameOver {
            printBoard()
            print("Player \(currentPlayer), enter your move (row and column):")
            if let input = readLine(), let row = Int(input.split(separator: " ")[0]), let col = Int(input.split(separator: " ")[1]) {
                gameOver = playMove(row: row, col: col)
            } else {
                print("Invalid input. Please enter row and column as numbers separated by a space.")
            }
        }
    }
}

//Starts a game

let game = TicTacToe()
game.playGame()
