
import Foundation

//The class  can be used for any N-size board (including 4 queens, but scalable for larger sizes).

class NQueens {
    private var board: [[Int]]

    init(size: Int) {
        board = Array(repeating: Array(repeating: 0, count: size), count: size)
    }

    // This function checks if placing a queen is safe. It checks the column, the left diagonal, and the right diagonal. The row does not need to be checked because only one queen will be placed per row.
    
    private func isSafe(row: Int, col: Int) -> Bool {
        //Check column
        
        for i in 0..<row {
            if board[i][col] == 1 {
                return false
            }
        }

        //Check left diagonal
        
        var i = row, j = col
        while i >= 0 && j >= 0 {
            if board[i][j] == 1 { return false }
            i -= 1
            j -= 1
        }

        //Check right diagonal
        
        i = row
        j = col
        while i >= 0 && j < board.count {
            if board[i][j] == 1 { return false }
            i -= 1
            j += 1
        }

        return true
    }

    //This function attempts to solve the N-Queens problem by backtracking. It tries to place queens row by row.
    
    private func solve(row: Int) -> Bool {
        if row == board.count { return true }

        for col in 0..<board.count {
            if isSafe(row: row, col: col) {
                board[row][col] = 1
                
                if solve(row: row + 1) {
                    return true
                }
                
                board[row][col] = 0
            }
        }
        
        return false
    }

    //Function to either print the board if a solution is found or print "No solution" if no solution is found.
    
    func solveNQueens() {
        if solve(row: 0) {
            printBoard()
        } else {
            print("No solution found")
        }
    }

    //This function prints the board, showing queens with "Q" and empty spaces with ".".
    
    private func printBoard() {
        for row in board {
            print(row.map { $0 == 1 ? "Q" : "." }.joined(separator: " "))
        }
    }
}

//Initialize and solve for the 4-Queens problem.

let game = NQueens(size: 4)
game.solveNQueens()

