
import Foundation

// This code modifies what we did in class to introduce the idea of weighing user preferences to show how likely it is for a person to like the car.

//Property wrapper to validate the price (expands on concepts in class to make sure there are no negatives)

@propertyWrapper
struct ValidatePrice {
    private var value: Double
    
    var wrappedValue: Double {
        get { value }
        set { value = max(newValue, 0) }
    }
    
    init(wrappedValue: Double) {
        self.value = max(wrappedValue, 0)
    }
}

// Car structure with variables that can be used to identify the car later. Also returns a string with make, model, and year variables if the function carDescription is called.

struct Car {
    var make: String
    var model: String
    var year: Int
    @ValidatePrice var price: Double
    var isSportsCar: Bool
    var fuelEfficiency: Double
    var safetyRating: Double
    
    func carDescription() -> String {
        return "\(year) \(make) \(model): $\(price)"
    }
}

//Class with variables that can be used to describe/contact the person.It also allows the user to create instances for multiple people.This is universally used for both the customer and the salesperson to decrease redundancy in the code.

class Person {
    var name: String
    var contactNumber: String
    
    init(name: String, contactNumber: String) {
        self.name = name
        self.contactNumber = contactNumber
    }
    
    func contactInfo() -> String {
        return "Name: \(name), Contact Number: \(contactNumber)"
    }
}

// This is the class used to add cars to the list of cars that the customer has purchased and return that list as a string with a new line for each car.

class Customer: Person {
    var purchasedCars: [Car] = []
    
    func addCar(car: Car) {
        purchasedCars.append(car)
    }
    
    func listPurchasedCars() -> String {
        return purchasedCars.map { $0.carDescription() }.joined(separator: "\n")
    }
}

// The salesperson class builds upon the person class to add the salesperson's Employee ID.

class Salesperson: Person {
    var employeeID: String
    
    init(name: String, contactNumber: String, employeeID: String) {
        self.employeeID = employeeID
        super.init(name: name, contactNumber: contactNumber)
    }
    
    override func contactInfo() -> String {
        return super.contactInfo() + ", Employee ID: \(employeeID)"
    }
}

//This is the function that I came up with to quantify possible preferences that the user may have. Each car is given a score based on how much that car fits the preference type(1-10). the user also give a percentage on how much they perfer it (0-1)These preferences could be if it is a sports car, if it is fuel efficient, or if higher price is an issue. I assumed that if its a sports car, it automatically gets the full 10 points. It also multiplies the miles per gallon by the user's preferences (which could skew results to favor fuel efficiency over all). It also assumes that the cost of a car in the dealersip cannot exceed 100,000.

func compareVehicles(userPreferences: [String: Double], cars: [Car]) -> [String: Double] {
    var scores: [String: Double] = [:]
    
    for car in cars {
        var score = 0.0

        if let sportsCarPref = userPreferences["sportsCar"], car.isSportsCar {
            score += sportsCarPref * 10
        }
        
        if let fuelEfficiencyPref = userPreferences["fuelEfficiency"] {
            score += car.fuelEfficiency * fuelEfficiencyPref
        }

        if let safetyPref = userPreferences["safety"] {
            score += car.safetyRating * safetyPref
        }

        if let pricePref = userPreferences["priceSensitivity"] {
            score += ((100000 - car.price) / 1000) * pricePref
        }
        
        scores["\(car.year) \(car.make) \(car.model)"] = score
    }
    
    return scores
}

//Initializes three types of cars with expanded attributes for preference scoring.

let car1 = Car(make: "Toyota", model: "Camry", year: 2020, price: 20000, isSportsCar: false, fuelEfficiency: 35, safetyRating: 9.0)
let car2 = Car(make: "Ford", model: "Mustang", year: 2024, price: 45000, isSportsCar: true, fuelEfficiency: 22, safetyRating: 8.5)
let car3 = Car(make: "Honda", model: "Civic", year: 2023, price: 22000, isSportsCar: false, fuelEfficiency: 38, safetyRating: 9.2)

//Creates an instance of a customer

let customer = Customer(name: "John Doe", contactNumber: "123-123-1233")
customer.addCar(car: car1)
customer.addCar(car: car2)
customer.addCar(car: car3)

//Creates an instance of a salesperson and the cars that the person has purchased from the salesperson.

let salesperson = Salesperson(name: "Jane Smith", contactNumber: "987-654-3210", employeeID: "001")

print("\nCustomer Info:")
print(customer.contactInfo())
print("\nPurchased Cars:")
print(customer.listPurchasedCars())

print("\nSalesperson Info:")
print(salesperson.contactInfo())

//These numbers represent the percentage importance the user assigns to a preference.

let userPreferences: [String: Double] = [
    "sportsCar": 1.0,        //User really likes sports cars
    
    "fuelEfficiency": 0.5,   //User is impartial about fuel efficiency
    "safety": 0.8,           //User prefers safer cars
    "priceSensitivity": 0.6  //User moderately prefers cheaper cars
]

//creates a list of the cars to be compared and a dictionary with them and the user preferences.

let cars = [car1, car2, car3]
let comparisonScores = compareVehicles(userPreferences: userPreferences, cars: cars)

//Prints the results

print("\nVehicle Comparison Scores:")
for (car, score) in comparisonScores.sorted(by: { $0.value > $1.value }) {
    print("\(car): Score = \(score)")
}
